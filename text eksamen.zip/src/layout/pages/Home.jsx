import React from 'react'
import "./home.scss"


const Home = () => {
  return (
    <div className='lorem'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Labore molestias natus laudantium sed voluptatem dolorem ab illo accusantium, unde accusamus?</div>
  )
}

export default Home