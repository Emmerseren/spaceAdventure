import React from 'react'

const Rumfaergen = () => {
  return (
    <div>Rumfaergen</div>
  )
}

export default Rumfaergen