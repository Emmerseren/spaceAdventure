import React from 'react'

const Kontankt = () => {
  return (
    <div>Kontankt</div>
  )
}

export default Kontankt