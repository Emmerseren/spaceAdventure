import React from 'react'

const Galleri = () => {
  return (
    <div>Galleri</div>
  )
}

export default Galleri