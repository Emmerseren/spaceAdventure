import React from 'react'

const Sikkerhed = () => {
  return (
    <div>Sikkerhed</div>
  )
}

export default Sikkerhed