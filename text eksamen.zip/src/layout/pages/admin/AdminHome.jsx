import React from 'react'

const AdminHome = () => {
  return (
    <div>AdminHome</div>
  )
}

export default AdminHome