import React from 'react'

const Ture = () => {
  return (
    <div>Ture</div>
  )
}

export default Ture